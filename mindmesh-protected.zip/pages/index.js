import { useState } from 'react';

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');

  const checkPassword = () => {
    if (password === 'test123') {
      setAuthenticated(true);
    } else {
      alert('Incorrect password');
    }
  };

  const handleInsight = () => {
    setOutput(`Compatibility analysis for: "${input}"\nBalanced teams with complementary traits (like introvert + extrovert) often perform best with communication.`);
  };

  if (!authenticated) {
    return (
      <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
        <h2>Enter Password to Access MindMesh</h2>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button onClick={checkPassword}>Enter</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#5C4DFF' }}>MindMesh</h1>
      <p>Analyze team personality compatibility using MBTI and simulated traits.</p>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="e.g. How will Alex (ENTJ) and Jamie (INFP) work together?"
        style={{ width: '100%', padding: 10 }}
      />
      <button onClick={handleInsight} style={{ marginTop: 10 }}>Get Insight</button>
      {output && (
        <pre style={{ marginTop: 20, background: '#f0f4f8', padding: 20 }}>{output}</pre>
      )}
    </div>
  );
}