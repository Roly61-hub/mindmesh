
export default function TeamPage() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>MindMesh Team Dashboard</h1>
      <p>This is the core functionality area of the app.</p>
    </div>
  );
}
