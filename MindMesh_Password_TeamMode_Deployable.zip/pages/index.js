
import { useState } from 'react';
import { useRouter } from 'next/router';

export default function PasswordGate() {
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password === 'mindmesh2024') {
      router.push('/team');
    } else {
      alert('Incorrect password');
    }
  };

  return (
    <div style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Welcome to MindMesh</h1>
      <form onSubmit={handleSubmit}>
        <input 
          type="password" 
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ padding: '0.5rem', fontSize: '1rem' }}
        />
        <button type="submit" style={{ marginLeft: '1rem', padding: '0.5rem 1rem' }}>
          Enter
        </button>
      </form>
    </div>
  );
}
