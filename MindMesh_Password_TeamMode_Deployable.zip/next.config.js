
module.exports = {
  reactStrictMode: true,
}
