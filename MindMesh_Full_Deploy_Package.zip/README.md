# MindMesh

Password-gated team personality analysis app built with Vite + React.