MindMesh Deploy Ready ZIP

This will contain the full app including password gate, /team landing, and UI improvements.
Password: Rarerer
