
# MindMesh Drop Deployment (Vercel)

✅ Drag this ZIP file to https://vercel.com/drop  
✅ Default route: /team  
✅ Password gate: Enabled (password: `beta2025`)  
