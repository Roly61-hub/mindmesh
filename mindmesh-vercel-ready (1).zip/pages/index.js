// This file is optional and can be empty since root is redirected to /team
export default function Home() {
  return null;
}