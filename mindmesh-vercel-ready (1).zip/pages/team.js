export default function TeamPage() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>MindMesh Team Page</h1>
      <p>This is the full app experience. Password gating and full team analysis goes here.</p>
    </div>
  );
}